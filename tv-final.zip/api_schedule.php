<?php
header('Content-Type: application/json; charset=utf-8');

function safe_fetch_json(string $url, int $timeout = 12): ?array {
    // محاولة باستخدام curl أولاً (أسرع وأكثر أماناً)
    if (function_exists('curl_init')) {
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_USERAGENT => 'IPTV-Schedule/2.0',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        $response = curl_exec($curl);
        curl_close($curl);
        
        if ($response !== false && !empty($response)) {
            $json = json_decode($response, true);
            if (is_array($json)) return $json;
        }
    }
    
    // محاولة باستخدام file_get_contents كبديل
    $ctx = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => $timeout,
            'header' => "User-Agent: IPTV-Schedule/2.0\r\nAccept: application/json\r\n",
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ]
    ]);

    $body = @file_get_contents($url, false, $ctx);
    if ($body === false || $body === '') {
        return null;
    }

    $json = json_decode($body, true);
    return is_array($json) ? $json : null;
}

function normalize_sportsdb_event(array $e): array {
    return [
        'idEvent' => (string)($e['idEvent'] ?? uniqid('ev_', true)),
        'dateEvent' => $e['dateEvent'] ?? '',
        'strTime' => $e['strTime'] ?? '',
        'strLeague' => $e['strLeague'] ?? 'مباراة',
        'strEvent' => $e['strEvent'] ?? (($e['strHomeTeam'] ?? 'Team A') . ' vs ' . ($e['strAwayTeam'] ?? 'Team B')),
        'strHomeTeam' => $e['strHomeTeam'] ?? 'Team A',
        'strAwayTeam' => $e['strAwayTeam'] ?? 'Team B',
        'strHomeTeamBadge' => $e['strHomeTeamBadge'] ?? null,
        'strAwayTeamBadge' => $e['strAwayTeamBadge'] ?? null,
        'intHomeScore' => isset($e['intHomeScore']) ? $e['intHomeScore'] : null,
        'intAwayScore' => isset($e['intAwayScore']) ? $e['intAwayScore'] : null,
        'strStatus' => $e['strStatus'] ?? null,
        'strTVStation' => $e['strTVStation'] ?? null,
        'strVenue' => $e['strVenue'] ?? null,
        'strVideo' => $e['strVideo'] ?? null,
    ];
}

function fallback_matches(string $date): array {
    // بيانات احتياطية أكثر واقعية مع وقت ديناميكي
    $matches = [
        [
            'idEvent' => 'local-' . md5($date . 'match1'),
            'dateEvent' => $date,
            'strTime' => '16:35:00',
            'strLeague' => 'جدول محلي',
            'strEvent' => 'النصر vs الهلال',
            'strHomeTeam' => 'نادي النصر',
            'strAwayTeam' => 'نادي الهلال',
            'strHomeTeamBadge' => null,
            'strAwayTeamBadge' => null,
            'intHomeScore' => null,
            'intAwayScore' => null,
            'strStatus' => null,
            'strTVStation' => 'beIN Sports 1',
            'strVenue' => 'ملعب الأمير فهد الدولي',
            'strVideo' => null,
        ],
        [
            'idEvent' => 'local-' . md5($date . 'match2'),
            'dateEvent' => $date,
            'strTime' => '19:30:00',
            'strLeague' => 'جدول محلي',
            'strEvent' => 'الاتحاد vs الشباب',
            'strHomeTeam' => 'نادي الاتحاد',
            'strAwayTeam' => 'نادي الشباب',
            'strHomeTeamBadge' => null,
            'strAwayTeamBadge' => null,
            'intHomeScore' => null,
            'intAwayScore' => null,
            'strStatus' => null,
            'strTVStation' => 'SSC Sports 1',
            'strVenue' => 'ملعب مدينة الملك عبدالله',
            'strVideo' => null,
        ],
        [
            'idEvent' => 'local-' . md5($date . 'match3'),
            'dateEvent' => $date,
            'strTime' => '22:00:00',
            'strLeague' => 'جدول محلي',
            'strEvent' => 'الأهلي vs الزمالك',
            'strHomeTeam' => 'النادي الأهلي',
            'strAwayTeam' => 'نادي الزمالك',
            'strHomeTeamBadge' => null,
            'strAwayTeamBadge' => null,
            'intHomeScore' => null,
            'intAwayScore' => null,
            'strStatus' => null,
            'strTVStation' => 'beIN Sports 2',
            'strVenue' => 'ملعب الدفاع الجوي',
            'strVideo' => null,
        ]
    ];
    
    return $matches;
}

$date = $_GET['date'] ?? gmdate('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $date = gmdate('Y-m-d');
}

// التحقق من أن التاريخ معقول (ليس في الماضي البعيد)
$dateObj = DateTime::createFromFormat('Y-m-d', $date);
if (!$dateObj || $dateObj->format('Y-m-d') !== $date) {
    $date = gmdate('Y-m-d');
}

$leagueIds = ['4328', '4335', '4480', '4332', '4331'];
$year = (int)gmdate('Y');
$month = (int)gmdate('n');
$season = $month >= 7 ? "$year-" . ($year + 1) : ($year - 1) . "-$year";

$events = [];
$attempts = 0;
$maxAttempts = 3;

// محاولة جلب البيانات من API مع إعادة المحاولة
foreach ($leagueIds as $leagueId) {
    $attempts++;
    if ($attempts > $maxAttempts) break;
    
    $url = "https://www.thesportsdb.com/api/v1/json/3/eventsseason.php?id={$leagueId}&s={$season}";
    
    $payload = safe_fetch_json($url);
    if (!empty($payload['events']) && is_array($payload['events'])) {
        foreach ($payload['events'] as $event) {
            $eventDate = $event['dateEvent'] ?? '';
            if ($eventDate === $date) {
                $events[] = normalize_sportsdb_event($event);
            }
        }
    }
    
    // إذا وجدنا أحداث كافية، توقف
    if (count($events) >= 3) break;
}

// إذا لم نجد أي أحداث، استخدم البيانات الاحتياطية
if (empty($events)) {
    $events = fallback_matches($date);
    $source = 'fallback';
} else {
    $source = 'api';
}

// فرز الأحداث حسب الوقت
usort($events, function($a, $b) {
    return strtotime($a['strTime'] ?? '00:00') - strtotime($b['strTime'] ?? '00:00');
});

echo json_encode([
    'date' => $date,
    'source' => $source,
    'count' => count($events),
    'timestamp' => time(),
    'events' => $events,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
